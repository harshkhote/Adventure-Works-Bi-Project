/* Total Profit*/

select distinct * from adventure_works_sales;
select sum(SalesAmount) as TotalSales,
sum(TotalProductCost) as TotalCost,
sum(SalesAmount-TotalProductCost) as TotalProfit
from sales;

/* Total Quantity*/
select sum(OrderQuantity) as TotalQuantity
from adventure_works_sales;

/* Total Sales */
select sum(SalesAmount) as TotalSales
from adventure_works_sales;

# Year-wise  Sales
SELECT 
    LEFT(OrderDateKey, 4) AS Year,
    SUM(UnitPrice * OrderQuantity) AS TotalSales
FROM adventure_works_sales
GROUP BY LEFT(OrderDateKey, 4)
ORDER BY Year;

 #Average Sales per Category
 SELECT 
    AVG(SalesByCategory) AS AverageSales
FROM (
    SELECT 
        ProductName,
        SUM(UnitPrice * OrderQuantity) AS SalesByCategory
    FROM adventure_works_sales
    GROUP BY ProductName
) AS sub;

 # Category-wise Total Sales
SELECT 
    ProductName,
    SUM(UnitPrice * OrderQuantity) AS TotalSales
FROM adventure_works_sales
GROUP BY ProductName
ORDER BY TotalSales DESC ;

# Top 10 sellig Product
SELECT 
    ProductName,
    SUM(UnitPrice * OrderQuantity) AS TotalSales
FROM adventure_works_sales
GROUP BY ProductName
ORDER BY TotalSales DESC
Limit 10;

 # Year, Month wise Sales 
 SELECT 
    LEFT(OrderDateKey, 4) AS Year,
    SUBSTRING(OrderDateKey, 5, 2) AS Month,
    SUM(UnitPrice * OrderQuantity) AS TotalSales
FROM adventure_works_sales
GROUP BY 
    LEFT(OrderDateKey, 4), 
    SUBSTRING(OrderDateKey, 5, 2)
ORDER BY Year, Month desc;

#. Average Monthly Sales
SELECT 
    LEFT(OrderDateKey, 4) AS Year,
    SUBSTRING(OrderDateKey, 5, 2) AS Month,
    SUM(UnitPrice * OrderQuantity) AS TotalSales
FROM adventure_works_sales
GROUP BY 
    LEFT(OrderDateKey, 4), 
    SUBSTRING(OrderDateKey, 5, 2)
ORDER BY TotalSales ASC;

